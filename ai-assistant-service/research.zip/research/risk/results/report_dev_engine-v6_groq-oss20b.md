# Kết quả thực nghiệm: split=dev, lớp A=full, 150 ca có nhãn chuẩn


## Mức rủi ro

| Cấu hình | n | Thất bại | Chính xác | Macro F1 [95% bootstrap] | Bỏ sót HIGH | Bỏ sót HIGH thành LOW | Báo sai HIGH | Mô hình |
|:--|--:|--:|:--|:--|:--|:--|:--|:--|
| C0 | 150 | 0 | 64.7% [56.7%, 71.9%] | 58.4% [50.8%, 66.1%] | 32.1% [21.4%, 45.2%] | 23.2% [14.1%, 35.8%] | 0.0% [0.0%, 3.9%] | - |
| C1 | 150 | 0 | 79.3% [72.2%, 85.0%] | 78.9% [71.9%, 85.3%] | 23.2% [14.1%, 35.8%] | 12.5% [6.2%, 23.6%] | 0.0% [0.0%, 3.9%] | - |
| C3 | 150 | 0 | 88.7% [82.6%, 92.8%] | 88.4% [83.0%, 93.1%] | 10.7% [5.0%, 21.5%] | 0.0% [0.0%, 6.4%] | 0.0% [0.0%, 3.9%] | openai/gpt-oss-20b |
| C4 | 150 | 0 | 88.7% [82.6%, 92.8%] | 88.4% [83.0%, 93.1%] | 10.7% [5.0%, 21.5%] | 0.0% [0.0%, 6.4%] | 0.0% [0.0%, 3.9%] | openai/gpt-oss-20b |
| C5 | 150 | 0 | 90.0% [84.2%, 93.8%] | 89.5% [84.2%, 93.9%] | 5.4% [1.8%, 14.6%] | 0.0% [0.0%, 6.4%] | 3.2% [1.1%, 9.0%] | openai/gpt-oss-20b |

## Precision, recall, F1 theo mức

| Cấu hình | Mức | Số ca thật | Precision | Recall | F1 |
|:--|:--|--:|--:|--:|--:|
| C0 | LOW | 52 | 52.0% | 100.0% | 68.4% |
| C0 | MEDIUM | 42 | 58.3% | 16.7% | 25.9% |
| C0 | HIGH | 56 | 100.0% | 67.9% | 80.9% |
| C1 | LOW | 52 | 70.1% | 90.4% | 79.0% |
| C1 | MEDIUM | 42 | 72.5% | 69.0% | 70.7% |
| C1 | HIGH | 56 | 100.0% | 76.8% | 86.9% |
| C3 | LOW | 52 | 91.8% | 86.5% | 89.1% |
| C3 | MEDIUM | 42 | 74.5% | 90.5% | 81.7% |
| C3 | HIGH | 56 | 100.0% | 89.3% | 94.3% |
| C4 | LOW | 52 | 91.8% | 86.5% | 89.1% |
| C4 | MEDIUM | 42 | 74.5% | 90.5% | 81.7% |
| C4 | HIGH | 56 | 100.0% | 89.3% | 94.3% |
| C5 | LOW | 52 | 92.0% | 88.5% | 90.2% |
| C5 | MEDIUM | 42 | 81.8% | 85.7% | 83.7% |
| C5 | HIGH | 56 | 94.6% | 94.6% | 94.6% |

## Ma trận nhầm lẫn (hàng: nhãn chuẩn, cột: dự đoán)

**C0**

| | LOW | MEDIUM | HIGH |
|:--|--:|--:|--:|
| LOW | 52 | 0 | 0 |
| MEDIUM | 35 | 7 | 0 |
| HIGH | 13 | 5 | 38 |

**C1**

| | LOW | MEDIUM | HIGH |
|:--|--:|--:|--:|
| LOW | 47 | 5 | 0 |
| MEDIUM | 13 | 29 | 0 |
| HIGH | 7 | 6 | 43 |

**C3**

| | LOW | MEDIUM | HIGH |
|:--|--:|--:|--:|
| LOW | 45 | 7 | 0 |
| MEDIUM | 4 | 38 | 0 |
| HIGH | 0 | 6 | 50 |

**C4**

| | LOW | MEDIUM | HIGH |
|:--|--:|--:|--:|
| LOW | 45 | 7 | 0 |
| MEDIUM | 4 | 38 | 0 |
| HIGH | 0 | 6 | 50 |

**C5**

| | LOW | MEDIUM | HIGH |
|:--|--:|--:|--:|
| LOW | 46 | 5 | 1 |
| MEDIUM | 4 | 36 | 2 |
| HIGH | 0 | 3 | 53 |

## Theo mã vi phạm (cấu hình có trả mã)

| Cấu hình | Mã | Số ca thật | Precision | Recall | F1 |
|:--|:--|--:|--:|--:|--:|
| C0 | PROHIBITED_GOODS | 41 | 100.0% | 78.0% | 87.7% |
| C0 | OFF_PLATFORM_CONTACT | 24 | 100.0% | 37.5% | 54.5% |
| C0 | SCAM | 9 | 100.0% | 66.7% | 80.0% |
| C0 | OVERPROMISE | 8 | 100.0% | 75.0% | 85.7% |
| C0 | ORGANIZER_RISK | 51 | 0.0% | 0.0% | 0.0% |
| C0 | PRICE_ANOMALY | 7 | 0.0% | 0.0% | 0.0% |
| C0 | DUPLICATE | 2 | 0.0% | 0.0% | 0.0% |
| C0 | SCHEDULE_ANOMALY | 3 | 0.0% | 0.0% | 0.0% |
| C1 | PROHIBITED_GOODS | 41 | 100.0% | 78.0% | 87.7% |
| C1 | OFF_PLATFORM_CONTACT | 24 | 100.0% | 37.5% | 54.5% |
| C1 | SCAM | 9 | 100.0% | 66.7% | 80.0% |
| C1 | OVERPROMISE | 8 | 100.0% | 75.0% | 85.7% |
| C1 | ORGANIZER_RISK | 51 | 98.1% | 100.0% | 99.0% |
| C1 | PRICE_ANOMALY | 7 | 100.0% | 85.7% | 92.3% |
| C1 | DUPLICATE | 2 | 7.1% | 50.0% | 12.5% |
| C1 | SCHEDULE_ANOMALY | 3 | 100.0% | 100.0% | 100.0% |
| C3 | PROHIBITED_GOODS | 41 | 94.9% | 90.2% | 92.5% |
| C3 | OFF_PLATFORM_CONTACT | 24 | 92.3% | 100.0% | 96.0% |
| C3 | SCAM | 9 | 100.0% | 88.9% | 94.1% |
| C3 | OVERPROMISE | 8 | 100.0% | 75.0% | 85.7% |
| C3 | ORGANIZER_RISK | 51 | 98.1% | 100.0% | 99.0% |
| C3 | PRICE_ANOMALY | 7 | 100.0% | 85.7% | 92.3% |
| C3 | DUPLICATE | 2 | 7.1% | 50.0% | 12.5% |
| C3 | SCHEDULE_ANOMALY | 3 | 100.0% | 100.0% | 100.0% |
| C4 | PROHIBITED_GOODS | 41 | 94.9% | 90.2% | 92.5% |
| C4 | OFF_PLATFORM_CONTACT | 24 | 92.3% | 100.0% | 96.0% |
| C4 | SCAM | 9 | 100.0% | 88.9% | 94.1% |
| C4 | OVERPROMISE | 8 | 100.0% | 75.0% | 85.7% |
| C4 | ORGANIZER_RISK | 51 | 98.1% | 100.0% | 99.0% |
| C4 | PRICE_ANOMALY | 7 | 100.0% | 85.7% | 92.3% |
| C4 | DUPLICATE | 2 | 7.1% | 50.0% | 12.5% |
| C4 | SCHEDULE_ANOMALY | 3 | 100.0% | 100.0% | 100.0% |
| C5 | PROHIBITED_GOODS | 41 | 97.4% | 90.2% | 93.7% |
| C5 | OFF_PLATFORM_CONTACT | 24 | 92.3% | 100.0% | 96.0% |
| C5 | SCAM | 9 | 100.0% | 88.9% | 94.1% |
| C5 | OVERPROMISE | 8 | 100.0% | 75.0% | 85.7% |
| C5 | ORGANIZER_RISK | 51 | 98.1% | 100.0% | 99.0% |
| C5 | PRICE_ANOMALY | 7 | 100.0% | 85.7% | 92.3% |
| C5 | DUPLICATE | 2 | 7.1% | 50.0% | 12.5% |
| C5 | SCHEDULE_ANOMALY | 3 | 100.0% | 100.0% | 100.0% |

## Lớp mô hình

| Cấu hình | Cờ đề xuất | Cờ giữ lại | Bị loại ở đọc lần hai | Trùng luật bị bỏ | Độ trễ TB (ms) | p95 (ms) |
|:--|--:|--:|--:|--:|--:|--:|
| C3 | 72 | 72 | 0 | 0 | 16 | 24 |
| C4 | 72 | 71 | 0 | 0 | 15 | 30 |
| C5 | 72 | 69 | 2 | 44 | 13 | 17 |
*Độ trễ có thể gồm cả câu trả lời lấy từ bộ nhớ đệm; chỉ số độ trễ thật nằm ở cột llm_ms của tệp kết quả.*

## So sánh cặp với C5 (McNemar chính xác, hiệu chỉnh Holm)

| Cấu hình | Chỉ cấu hình đúng | Chỉ C5 đúng | p | p (Holm) |
|:--|--:|--:|--:|--:|
| C0 | 6 | 44 | 0.0000 | 0.0000 |
| C1 | 1 | 17 | 0.0001 | 0.0004 |
| C3 | 2 | 4 | 0.6875 | 1.0000 |
| C4 | 2 | 4 | 0.6875 | 1.0000 |
